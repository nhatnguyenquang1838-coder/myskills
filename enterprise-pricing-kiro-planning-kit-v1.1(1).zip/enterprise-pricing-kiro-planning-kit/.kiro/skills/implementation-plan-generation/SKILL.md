---
name: implementation-plan-generation
description: Generate a traceable implementation plan with requirements, architecture, waves, epics, atomic tasks, dependencies, estimates, tests, rollback, risks and evidence.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Preconditions

P0–P3 evidence must exist. Do not generate a confident final plan from missing critical inputs; generate a conditional plan with explicit blockers instead.

# Procedure

1. Consolidate specialist outputs.
2. Resolve or expose contradictions.
3. Define implementation options for open architecture choices.
4. Select MVP and later waves.
5. Build dependency graph and critical path.
6. Create epics, features and atomic tasks.
7. Add acceptance criteria, testing, rollout, rollback and evidence.
8. Build traceability from source to task.
9. Run schema and consistency validation.

# Atomic task rule

A task should be independently reviewable, testable and attributable to one primary owner skill. Split tasks that combine unrelated components or cannot be completed in one controlled change.
