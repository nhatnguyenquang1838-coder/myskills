---
name: architecture-review-board
description: Perform cross-discipline architecture review across business, T24, MuleSoft, Java, data, rules, BPM, ML, security, testing and operations before plan publication.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Review method

For every specialist domain, state PASS, CONDITIONAL or BLOCKED.

Check:

- Ownership contradictions.
- Hidden synchronous dependencies.
- Logic placed in the wrong system.
- Missing data and freshness semantics.
- Non-deterministic calculation.
- Missing audit/replay.
- Contracting inconsistency.
- Security and regulatory gaps.
- Incomplete test or rollback strategy.
- Tasks that are too broad or not traceable.

Publish dissenting findings rather than manufacturing consensus.
