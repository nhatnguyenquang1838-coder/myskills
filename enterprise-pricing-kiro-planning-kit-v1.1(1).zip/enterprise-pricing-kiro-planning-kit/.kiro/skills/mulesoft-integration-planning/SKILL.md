---
name: mulesoft-integration-planning
description: Design MuleSoft-governed external interfaces, API layers, transformations, security, correlation, throttling, batch orchestration and error handling without moving pricing logic into Mule.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Inventory consumers and providers.
2. Define experience, process and system API responsibilities where useful.
3. Create OpenAPI/event/file contracts.
4. Define auth, rate limits, correlation and error model.
5. Separate synchronous APIs from bulk transfer.
6. Define retry and dead-letter handling.
7. Produce sequence diagrams and interface ownership.

# Constraint

No product resolution, campaign qualification or factor calculation in Mule flows.
