---
name: rules-and-decision-engine
description: Design deterministic pricing rules, decision tables, formula execution, eligibility, conflict handling, validation, versioning, testing and explainability.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

- Classify rules: eligibility, base price, adjustment, campaign, guardrail and rounding.
- Define evaluation graph and execution order.
- Detect circular dependencies and ambiguous priorities.
- Define typed inputs and outputs.
- Define rule version lifecycle and safe activation.
- Create golden datasets and boundary tests.
- Produce evaluation evidence for every qualified and rejected rule.

Do not select Drools, DMN or a custom engine without option analysis and approved constraints.
