---
inclusion: always
---
# Evidence Rules

Classify every material statement as one of:

- FACT: directly supported by a supplied source.
- DECISION: explicitly approved project direction.
- ASSUMPTION: temporary planning input requiring validation.
- INFERENCE: reasoned conclusion derived from facts.
- OPEN: unresolved question or unavailable evidence.

Every epic and high-risk task must cite source sections or decision IDs. Conflicting sources must be recorded, not silently reconciled.
