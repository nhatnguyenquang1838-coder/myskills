---
inclusion: auto
name: contracting-boundary
description: Use for contracting, quote application, revalidation, pricing instruction, downstream application, idempotency, partial success or reconciliation.
---
# Contracting Boundary

Computing is non-binding until a quote is revalidated and approved for contract use.

Contracting design must define:

- Target system and financial booking owner.
- Required revalidation fields.
- Quote validity and revocation.
- Idempotency ownership and key.
- Partial-application state model.
- Retry, compensation and reconciliation.
- Evidence returned by the target system.
