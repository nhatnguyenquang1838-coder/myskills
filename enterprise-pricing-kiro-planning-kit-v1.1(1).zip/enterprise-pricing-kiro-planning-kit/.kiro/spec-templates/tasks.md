# <SPEC-ID> — Implementation Tasks

## Delivery waves

## Dependency graph

## Critical path

## Epics

### EP-01 — <Epic>

#### TASK-001 — <Atomic task>

- Requirements:
- Design components:
- Owner skill:
- Dependencies:
- Complexity:
- Estimate assumption:

**Objective**

**Implementation guidance**

**Acceptance criteria**

**Test evidence**

**Migration and rollback**

**Risks and assumptions**
