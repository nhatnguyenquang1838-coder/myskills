---
name: pm-program-planning
description: Create PM-level program plans including scope, milestone roadmap, Gantt structure, resource model, cost model, RAID, dependency governance, and executive reporting.
metadata:
  domain: enterprise-pricing
  version: "1.1"
---

# Purpose

Convert analysis outputs into a practical PM planning package for Enterprise Pricing delivery.

# Planning outputs

Must produce:

- Program charter.
- Scope and out-of-scope.
- Milestone roadmap.
- Gantt-ready work breakdown structure.
- Resource plan by role and wave.
- Cost estimate by role/month and contingency.
- Dependency map.
- RAID log.
- Governance cadence.
- Decision calendar.
- Executive summary.

# Planning model

Plan at three levels:

```text
Level 1: Program waves
Level 2: Product slices and shared platform tracks
Level 3: Engineering work packages and milestones
```

# Gantt structure

Use this default sequencing:

1. Discovery and artifact clarification.
2. Architecture baseline and ADRs.
3. Shared platform foundation.
4. Data enablement.
5. First product compute slice.
6. Simulation and operational hardening.
7. Contracting bridge.
8. Pilot release.
9. Scale-out product rollout.

# Cost model

Cost must show:

```yaml
roles:
  - role:
    fte:
    months:
    rate_assumption:
    cost:
contingency:
tooling_cost:
infra_cost:
vendor_cost:
total_range:
confidence:
```

If rates are not provided, use placeholders and calculate effort-based person-months only.

# Governance cadence

Minimum cadence:

- Daily engineering sync.
- Twice-weekly dependency review.
- Weekly PM status.
- Weekly architecture review.
- Weekly RAID review.
- Bi-weekly steering committee.
- Release readiness review before every release.

# Output contract

Produce a PM plan with:

- Timeline table.
- Milestone table.
- Role/FTE table.
- Cost table.
- Dependency table.
- RAID table.
- Decision log.
- Reporting template.
