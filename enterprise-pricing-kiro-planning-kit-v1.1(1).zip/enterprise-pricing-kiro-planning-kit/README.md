# Enterprise Pricing — Kiro Planning Kit

A workspace-scoped Kiro package for analysing a complex Enterprise Pricing solution and producing an evidence-backed implementation plan.

This kit is designed for a first-pass **One-Man Army** planning mode: PM + BA + Solution Architect + Engineering Lead + DevOps + Security. It can later be split into specialist agents.

## Target solution baseline

- T24 is an upstream operational data source.
- T24 integration uses API and batch.
- The Pricing Engine owns a dedicated operational Data Store.
- MuleSoft is the mandatory API/integration gateway.
- Data Lake Golden Zone supplies curated analytical factors.
- Pricing Product maps primarily by T24 Product Code.
- Delivery is computing-first, with partial contracting integration later.
- Temenos Enterprise Product/Pricing is a capability reference, not a drop-in design.

## Package contents

- `.kiro/steering/`: persistent workspace knowledge and planning rules.
- `.kiro/skills/`: on-demand business, engineering, PM, DevOps and Security skills.
- `.kiro/agents/`: specialist Kiro IDE agents, led by `engineering-lead` or `one-man-army-planning-lead`.
- `.kiro/spec-templates/`: required structure for requirements, design, tasks and planning outputs.
- `knowledge/`: project knowledge base and planning models.
- `schemas/`: machine-checkable contracts for plans, tasks and decisions.
- `scripts/`: deterministic validators.
- `examples/`: kickoff prompt and sample output skeleton.

## Recommended first run

1. Put Solution Design under `inputs/solution/`.
2. Put BRD and FSD under `inputs/solution/` or a clearly named subfolder.
3. Put API/interface files under `inputs/interfaces/`.
4. Put T24 and Golden Zone dictionaries under `inputs/data/`.
5. Put NFR, SLA, volume and security expectations under `inputs/nfr/`.
6. Select `one-man-army-planning-lead` for first-pass planning.
7. Use `examples/kickoff-prompt.md` or ask for a full planning package.
8. Require output under `.kiro/specs/<SPEC-ID>/`.
9. Run `python3 scripts/validate_plan.py .kiro/specs/<SPEC-ID>`.

## Planning lifecycle

```text
P0 Artifact intake and question-back
P1 Business/product alignment
P2 Architecture and system feasibility
P3 Quantified development planning and estimation
P4 Release, test, deployment and security planning
P5 Cross-discipline review and publication
P6 Human approval and baseline freeze
```

No implementation work should start until P6 passes and a human approves the generated plan.

## Planning unit

Plan vertically by product/business journey, then decompose horizontally by system.

```text
Product / Journey
  → Capability
    → Feature
      → System work package
        → Atomic engineering task
```

## Required planning outputs

The planning package must include:

- Artifact clarification pack for Solution Design, BRD and FSD.
- Question-back register.
- Scope and MVP statement.
- Program roadmap.
- High-level Gantt.
- Timeline and milestone plan.
- Resource plan.
- Cost estimate.
- Detailed development plan.
- Release plan.
- Test plan.
- Deployment plan.
- Security plan.
- AI adoption and HITL plan.
- RAID log.
- Decision log.
- Dependency and critical path map.
- Traceability matrix.

## Quantified development planning

Development estimates must include:

- Feature taxonomy.
- Common baseline separation.
- Complexity scoring.
- Dependency factor.
- Uncertainty factor.
- AI adoption factor.
- HITL effort.
- Confidence band.
- Contingency.

A valid estimate must not be a single number without assumptions.

## AI adoption and HITL

AI may support:

- BRD/FSD extraction.
- Requirement traceability.
- API contract drafts.
- Java scaffolding.
- Mapping code.
- Unit tests.
- Rule scenarios.
- Gantt/resource first drafts.
- Runbooks and checklists.

AI must not own final decisions for pricing approval, security exceptions, budget commitment, production release, or contracting financial instruction.

## Key agents

- `one-man-army-planning-lead`: first-pass PM/BA/SA/Engineering/DevOps/Security planner.
- `engineering-lead`: accountable engineering planner.
- `program-manager`: PM plan, Gantt, resource, cost and RAID.
- `development-planning-lead`: quantified engineering estimate and AI/HITL plan.
- `devops-release-lead`: release, deployment, CI/CD and operations.
- `security-lead`: security, privacy, threat model and controls.
- Existing specialist agents: T24, MuleSoft, Java, Data/ML, BPM, Rules, Quality/NFR and Architecture Review Board.

## Key skills

Planning and management:

- `brd-fsd-solution-clarification`
- `pm-program-planning`
- `development-planning-estimation`
- `ai-adoption-hitl-planning`

DevOps and security:

- `devops-release-deployment`
- `security-threat-risk-planning`

Business and engineering:

- `business-capability-analysis`
- `enterprise-pricing-domain`
- `pricing-product-campaign-modeling`
- `pricing-factor-catalog`
- `t24-source-analysis`
- `mulesoft-integration-planning`
- `golden-zone-data-planning`
- `java-backend-architecture`
- `rules-and-decision-engine`
- `bpm-contracting-planning`
- `ml-pricing-planning`
- `nfr-capacity-resilience`
- `test-and-operational-readiness`
- `implementation-plan-generation`
- `architecture-review-board`

## Output folder recommendation

```text
.kiro/specs/EPP-BASE-001-program-planning/
├── source-inventory.md
├── clarification-questions.md
├── requirements.md
├── design.md
├── tasks.md
├── program-plan.md
├── gantt-timeline.md
├── resource-cost-plan.md
├── release-plan.md
├── test-plan.md
├── deployment-plan.md
├── decisions.md
├── risks.md
└── traceability.md
```
