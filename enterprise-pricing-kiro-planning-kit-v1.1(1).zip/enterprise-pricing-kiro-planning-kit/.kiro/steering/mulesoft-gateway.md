---
inclusion: auto
name: mulesoft-gateway
description: Use for MuleSoft, APIs, integration, routing, transformations, system/process/experience APIs, batch orchestration or gateway design.
---
# MuleSoft Gateway Rules

MuleSoft owns external contracts, security policies, routing, throttling, correlation, protocol mediation and integration error routing.

Do not place product resolution, campaign qualification, factor calculation or pricing decisions in DataWeave or Mule flows.

For large batch payloads, MuleSoft may govern transfer and orchestration while data moves through managed file or object storage. Do not force bulk transfer through synchronous request/response APIs.
