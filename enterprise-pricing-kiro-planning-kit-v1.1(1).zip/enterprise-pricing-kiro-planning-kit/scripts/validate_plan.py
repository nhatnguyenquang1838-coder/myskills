#!/usr/bin/env python3
from pathlib import Path
import sys

spec = Path(sys.argv[1] if len(sys.argv) > 1 else '').resolve()
required = ['requirements.md','design.md','tasks.md','traceability.md','decisions.md','risks.md','source-inventory.md']
errors=[]
for name in required:
    p=spec/name
    if not p.exists(): errors.append(f'missing {name}')
    elif len(p.read_text(encoding="utf-8").strip()) < 80: errors.append(f'{name} appears incomplete')

if (spec/'tasks.md').exists():
    text=(spec/'tasks.md').read_text(encoding='utf-8').lower()
    for token in ['dependencies','acceptance criteria','test evidence','rollback']:
        if token not in text: errors.append(f'tasks.md missing section: {token}')

if errors:
    print('PLAN VALIDATION: FAIL')
    for e in errors: print('-',e)
    raise SystemExit(1)
print('PLAN VALIDATION: PASS')
