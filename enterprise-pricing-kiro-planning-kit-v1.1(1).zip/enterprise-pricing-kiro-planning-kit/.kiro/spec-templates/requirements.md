# <SPEC-ID> — Requirements

## Objective and outcomes

## Scope

### In scope

### Out of scope

## Actors and journeys

## Business capability requirements

Use IDs such as `REQ-BIZ-001`.

### REQ-BIZ-001 — <Title>

**Source:**

**Requirement:** WHEN <trigger>, THE SYSTEM SHALL <measurable behavior>.

**Acceptance criteria:**

## Data requirements

## Integration requirements

## Security and compliance requirements

## NFR requirements

## Assumptions and open questions
