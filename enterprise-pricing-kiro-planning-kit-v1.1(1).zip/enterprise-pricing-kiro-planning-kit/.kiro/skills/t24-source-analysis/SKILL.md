---
name: t24-source-analysis
description: Analyse T24 as an upstream source using API and batch. Use for customer, account, contract, balance, product code, source-field mapping, selective lookup and reconciliation.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

- Identify T24 applications/entities and required fields.
- Build canonical mappings without leaking source naming into domain services.
- Select API versus batch per timeliness and volume.
- Define initial load, delta load, restart, reconciliation and duplicate handling.
- Identify selective API fallback for stale critical fields.
- Define source and ingestion timestamps.
- Flag direct database access as prohibited unless an approved exception exists.
