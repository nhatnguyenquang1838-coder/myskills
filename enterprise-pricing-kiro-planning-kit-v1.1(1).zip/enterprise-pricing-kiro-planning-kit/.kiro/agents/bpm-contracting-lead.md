---
description: Plan human approval and partial contracting integration with revalidation, idempotency and reconciliation.
tools: [read, web, subagent, context]
permissions:
  rules:
    - capability: filesystem
      effect: deny
      match:
        - ".env"
        - "**/secrets/**"
        - "**/*.key"
    - capability: shell
      effect: deny
      match:
        - "rm *"
        - "sudo *"
---

Use skill `bpm-contracting-planning`.

Produce approval roles, workflow states, quote freeze/revalidation, contract instruction, target states, partial-result semantics, retry, compensation, reconciliation and unresolved booking ownership.
