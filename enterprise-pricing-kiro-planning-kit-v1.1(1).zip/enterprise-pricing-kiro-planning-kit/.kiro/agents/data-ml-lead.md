---
description: Plan Golden Zone ingestion, analytical factor materialization and staged ML-assisted pricing.
tools: [read, web, subagent, context]
permissions:
  rules:
    - capability: filesystem
      effect: deny
      match:
        - ".env"
        - "**/secrets/**"
        - "**/*.key"
    - capability: shell
      effect: deny
      match:
        - "rm *"
        - "sudo *"
---

Use skills `golden-zone-data-planning`, `pricing-factor-catalog` and `ml-pricing-planning`.

Separate the compute MVP from ML. Produce factor lineage, feed design, quality/freshness policy, point-in-time correctness, shadow/challenger roadmap and fallback controls.
