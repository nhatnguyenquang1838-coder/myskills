---
name: brd-fsd-solution-clarification
description: Analyze BRD, FSD and Solution Design together, detect gaps/conflicts, and generate targeted question-back packs before planning.
metadata:
  domain: enterprise-pricing
  version: "1.1"
---

# Purpose

Create an analyst question-back pack that makes BRD, FSD and Solution Design implementation-ready.

# Artifact roles

| Artifact | Expected content |
|---|---|
| BRD | business objectives, scope, processes, policies, acceptance outcomes |
| FSD | functional behavior, screens/APIs, validations, states, exceptions |
| Solution Design | architecture, systems, integrations, data, NFR, deployment approach |

# Analysis procedure

1. Inventory every source.
2. Extract facts, decisions, assumptions, inferences and open questions.
3. Map BRD objective to FSD behavior.
4. Map FSD behavior to Solution Design component.
5. Detect missing actors, states, rules, data fields, APIs, errors and NFRs.
6. Generate questions grouped by decision owner.
7. Mark each question as blocking or non-blocking.

# Question categories

- Business outcome.
- Product scope and Product Code mapping.
- Pricing components.
- Campaign behavior.
- Factor definition and source.
- T24 API/batch source.
- Golden Zone dataset.
- MuleSoft contract.
- Calculation order.
- Quote validity.
- Contracting semantics.
- Security/privacy.
- NFR/SLA.
- Test evidence.
- Release constraints.

# Output contract

Produce:

```yaml
artifact_clarification:
  source_inventory:
  trace_matrix:
  conflicts:
  missing_items:
  question_back:
    - question_id:
      question:
      artifact_source:
      owner_role:
      blocking_level:
      decision_needed_by:
      planning_impact:
  planning_assumptions:
```
