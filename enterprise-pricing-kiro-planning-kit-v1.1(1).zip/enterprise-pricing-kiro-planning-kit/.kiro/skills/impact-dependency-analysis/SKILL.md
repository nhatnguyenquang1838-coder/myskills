---
name: impact-dependency-analysis
description: Build system, data, API, delivery and organizational dependency graphs; identify critical path, parallel work, blockers, blast radius and sequencing.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

- Build component and interface dependency graphs.
- Distinguish hard, soft and external dependencies.
- Identify data readiness and environment dependencies.
- Identify shared schema and release coupling.
- Calculate critical path qualitatively when estimates are unavailable.
- Define integration stubs and contract-first parallelization.
- Mark every unresolved external dependency as a blocker or risk.
