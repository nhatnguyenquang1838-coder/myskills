# Open Questions Register

## Data freshness

- Which fields are required for quote-only computation?
- Which fields must be revalidated before contracting?
- Maximum tolerated age by factor and journey?
- Is selective T24 API fallback permitted when projection data is stale?

## Volume and performance

- Peak synchronous TPS?
- Batch volume and completion window?
- Quote p95/p99 target?
- Availability and DR targets?

## Contracting

- Which target system applies the price?
- Which components may be partially applied?
- Which system owns idempotency?
- How is failure compensated or reconciled?

## Product model

- Is Product Code sufficient for MVP resolution?
- Which contextual qualifiers are required: currency, legal entity, channel, segment or tenor?
- Which product family is the MVP?

## Governance

- Maker/checker roles?
- Approval thresholds?
- Emergency suspension and override policy?
- Required retention period for pricing evidence?
