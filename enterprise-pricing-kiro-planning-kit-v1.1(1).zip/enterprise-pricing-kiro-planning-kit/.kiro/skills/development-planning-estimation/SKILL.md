---
name: development-planning-estimation
description: Quantify development plans using feature taxonomy, common baseline, skill complexity, AI adoption factors, HITL gates, dependencies, and evidence-based estimation.
metadata:
  domain: enterprise-pricing
  version: "1.1"
---

# Purpose

Turn BRD, FSD and Solution Design into measurable engineering scope. This skill produces feature sizing, work package estimates, timeline drivers, resource assumptions and AI-adoption adjustments.

# Required inputs

- Business capability or product slice.
- Source references from BRD, FSD and Solution Design.
- Affected systems.
- Feature list or functional requirements.
- Known NFRs.
- Known assumptions and open questions.
- Available team skill profile, if provided.

# Estimation principles

1. Estimate by feature capability first, then distribute by system.
2. Separate common baseline work from product-specific work.
3. Use explicit complexity factors instead of single-point guessing.
4. Apply AI productivity only where task type is suitable.
5. Add HITL effort where architecture, security, data, pricing logic or production risk requires review.
6. Show ranges and confidence, not fake precision.

# Feature taxonomy

Classify every feature:

| Type | Examples | Planning treatment |
|---|---|---|
| F0 Common baseline | auth, audit, observability, CI/CD, schema migration | build once, reused by slices |
| F1 Configuration | pricing product, factors, campaign setup | medium reuse, high validation |
| F2 Compute logic | eligibility, base price, adjustments, guardrails | high rule/testing effort |
| F3 Integration | T24 API/batch, MuleSoft, Golden Zone | dependency and contract driven |
| F4 Data | projections, factor snapshots, DQ, freshness | test with volume and lineage |
| F5 Workflow | approval, contracting, reconciliation | HITL and failure semantics heavy |
| F6 Operations | monitoring, rollback, incident runbook | mandatory release readiness |
| F7 AI/ML | model, feature pipeline, explainability | staged: offline, shadow, controlled |

# Complexity scoring

For each feature, score 1–5:

| Factor | Meaning |
|---|---|
| Business complexity | number of rules, variants, exception paths |
| Integration complexity | number and maturity of external contracts |
| Data complexity | freshness, quality, volume, lineage, key matching |
| Engineering complexity | algorithms, concurrency, state, idempotency |
| NFR complexity | latency, availability, security, audit, resilience |
| Test complexity | permutations, golden datasets, E2E dependencies |
| Operational complexity | monitoring, rollback, support and reconciliation |

# Sizing formula

Use this baseline formula:

```text
complexity_index = average(complexity_factors)
raw_effort_days = baseline_days_by_feature_type * complexity_multiplier
adjusted_effort = raw_effort_days * dependency_factor * uncertainty_factor * ai_factor + hitl_days
```

Default multipliers:

```yaml
complexity_multiplier:
  1: 0.60
  2: 0.85
  3: 1.00
  4: 1.40
  5: 1.90

dependency_factor:
  none: 1.00
  one_external_team: 1.15
  multiple_external_teams: 1.30
  immature_contract: 1.50

uncertainty_factor:
  low: 1.00
  medium: 1.20
  high: 1.50

ai_factor:
  low_ai_fit: 0.95
  medium_ai_fit: 0.85
  high_ai_fit: 0.70
  no_ai: 1.00
```

Never use AI factor below 0.70 unless the repository already has reliable generators, tests and architecture templates.

# Baseline effort table

Initial person-day baseline before multipliers:

| Feature type | Baseline days |
|---|---:|
| Simple config CRUD | 3–5 |
| Versioned config CRUD with audit | 8–13 |
| Decision table/rule group | 5–10 |
| Pricing calculation component | 8–15 |
| External API integration | 8–15 |
| Batch ingestion flow | 10–18 |
| Data projection model | 6–12 |
| E2E quote journey | 15–25 |
| Contracting/revalidation journey | 20–35 |
| Performance/resilience hardening | 10–20 |
| Security controls and audit hardening | 8–18 |
| Operational dashboard/runbook | 6–12 |

# AI adoption scoring

Classify AI placement:

| AI fit | Where AI can help | HITL requirement |
|---|---|---|
| High | boilerplate, unit tests, DTOs, mappings, docs, test data, first-cut rules | engineer review |
| Medium | API contract draft, migration scripts, batch jobs, integration tests | lead review |
| Low | pricing algorithms, security design, data lineage, production rollback | architect/security review |
| Not allowed | approval decision, final estimate approval, prod secret handling | human owns |

# HITL gates

Add explicit human review effort for:

- Product pricing semantics.
- T24 source mapping.
- MuleSoft contract changes.
- Golden Zone factor definition.
- Rule calculation order.
- Security and privacy design.
- Contracting and financial impact.
- NFR and release readiness.
- Estimate baseline approval.

# Output contract

Produce:

```yaml
feature_inventory:
  - feature_id:
    source_refs:
    feature_type:
    affected_systems:
    complexity_scores:
    ai_fit:
    hitl_required:
    baseline_days:
    multipliers:
    estimated_days_range:
    confidence:
    assumptions:
    dependencies:

common_baseline:
product_slice_scope:
workstream_estimates:
resource_skill_matrix:
critical_path:
confidence_and_contingency:
```

# Refusal rule

Do not produce a single fixed date or cost without assumptions, range and confidence.
