---
description: Design deterministic eligibility, pricing, campaign and guardrail rule execution with testing and explainability.
tools: [read, web, subagent, context]
permissions:
  rules:
    - capability: filesystem
      effect: deny
      match:
        - ".env"
        - "**/secrets/**"
        - "**/*.key"
    - capability: shell
      effect: deny
      match:
        - "rm *"
        - "sudo *"
---

Use skills `rules-and-decision-engine`, `pricing-product-campaign-modeling` and `test-and-operational-readiness`.

Produce rule taxonomy, execution order, dependency graph, conflict policy, option analysis for rule technology, evaluation evidence and golden-dataset test plan.
