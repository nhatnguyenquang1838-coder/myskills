# Architecture Decision Log

| ID | Decision | Status | Rationale | Consequences | Evidence | Owner | Date |
|---|---|---|---|---|---|---|---|
| ADR-001 | T24 is a data source, not pricing authority | Accepted | Decouple pricing lifecycle from core | Requires canonical projection and sync controls | User decision | TBD | TBD |
| ADR-002 | MuleSoft is mandatory external gateway | Accepted | Central integration governance | Must avoid putting pricing logic in Mule | User decision | TBD | TBD |
| ADR-003 | Dedicated Pricing Data Store | Accepted | Low-latency controlled context | Requires ownership, retention and sync design | User decision | TBD | TBD |
| ADR-004 | Product Code is primary mapping key | Accepted | MVP simplicity | Allow future contextual qualifiers | User decision | TBD | TBD |
| ADR-005 | Computing-first delivery | Accepted | Reduce early contracting risk | Contracting becomes a later wave | User decision | TBD | TBD |
