---
inclusion: always
---
# Technology Direction

Use evidence from the target solution before selecting products or versions.

Planning defaults:

- Java and Spring Boot for backend services.
- MuleSoft for external API/integration governance.
- Relational database for configuration and decision metadata unless evidence requires another model.
- Batch ingestion plus selective source APIs.
- BPM/BPA for human approval, not real-time calculation.
- Deterministic rules for MVP; ML enters through shadow/challenger stages.
- OpenAPI/JSON Schema for contracts.
- Event or asynchronous messaging only when justified by journey and consistency requirements.

Do not invent exact framework versions. Validate them from repository or approved standards.
