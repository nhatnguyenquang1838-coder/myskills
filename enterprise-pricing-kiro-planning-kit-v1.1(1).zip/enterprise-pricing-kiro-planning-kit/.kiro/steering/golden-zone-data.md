---
inclusion: auto
name: golden-zone-data
description: Use for Data Lake Golden Zone, curated factors, features, analytical data, batch feeds, lineage, freshness or ML feature planning.
---
# Golden Zone Data Rules

The Golden Zone supplies curated analytical factors with lineage, business date, effective time, quality status and source version.

Runtime calculation must consume materialized factor values from the Pricing Data Store or a governed online store. It must not synchronously query raw lake data.

Define fallback and expiration independently for every factor.
