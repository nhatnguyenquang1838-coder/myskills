---
inclusion: always
---
# Workspace Structure

- `inputs/`: supplied solution, interface and data documents.
- `knowledge/`: curated knowledge base and templates.
- `.kiro/steering/`: persistent project rules.
- `.kiro/skills/`: portable planning skills.
- `.kiro/agents/`: specialist planning agents.
- `.kiro/specs/<SPEC-ID>/`: generated requirements, design, tasks and evidence.
- `schemas/`: validation contracts.
- `scripts/`: deterministic validation utilities.

Never overwrite source documents. Generated planning artifacts must be placed under a unique spec folder.
