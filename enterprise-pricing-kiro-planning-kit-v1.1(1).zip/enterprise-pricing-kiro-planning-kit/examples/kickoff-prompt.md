Use one-man-army-planning-lead.

Goal: create the first Enterprise Pricing planning baseline from Solution Design, BRD and FSD.

Operating mode:
- planning_only
- no implementation
- evidence-backed
- question-back required
- quantified estimate required
- AI adoption and HITL required

Solution baseline:
- T24 is data source only.
- T24 integration uses API and batch.
- Pricing Engine owns a dedicated operational Data Store.
- MuleSoft is the API/integration gateway for all external connections.
- Data Lake Golden Zone provides curated analytical factors.
- Product mapping starts from T24 Product Code.
- Delivery is computing-first; contracting is partial and later.
- Temenos Pricing is a capability reference only.

Read:
- inputs/solution/**
- inputs/interfaces/**
- inputs/data/**
- inputs/nfr/**
- inputs/decisions/**
- knowledge/**
- .kiro/steering/**

Produce `.kiro/specs/EPP-BASE-001-program-planning/` containing:
- source-inventory.md
- clarification-questions.md
- requirements.md
- design.md
- tasks.md
- program-plan.md
- gantt-timeline.md
- resource-cost-plan.md
- release-plan.md
- test-plan.md
- deployment-plan.md
- decisions.md
- risks.md
- traceability.md

Planning requirements:
1. Analyze Solution Design, BRD and FSD together.
2. Label every item as FACT, DECISION, ASSUMPTION, INFERENCE or OPEN.
3. Generate blocking and non-blocking questions.
4. Plan by product/business journey, then decompose by system.
5. Separate common baseline from product-specific scope.
6. Quantify development estimates using feature taxonomy, complexity, dependency, uncertainty, AI adoption factor and HITL effort.
7. Show ranges, confidence and contingency.
8. Produce Gantt-ready timeline, resource plan and cost model.
9. Include development plan, release plan, test plan and deployment plan.
10. Include DevOps, Security and operational readiness.
11. Do not provide committed date or cost without assumptions and human approval.
12. End with P0-P6 gate status and remaining decisions.
