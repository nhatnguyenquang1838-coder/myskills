---
inclusion: auto
name: pricing-domain
description: Use for pricing product, campaign, factor, benefit, component, rule, eligibility, simulation, quotation or pricing decision analysis.
---
# Pricing Domain Rules

Model base price, adjustments, benefits, guardrails and final price as separately explainable components.

Product Code is the primary mapping key for MVP, but the resolver must allow future qualifiers such as legal entity, currency, channel, customer segment and tenor.

A published Pricing Product, Campaign or Rule version is immutable. Calculation order and conflict handling must be deterministic.
