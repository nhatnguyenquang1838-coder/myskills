# Solution Baseline

## Confirmed decisions

| Area | Decision |
|---|---|
| T24 | Operational data source |
| T24 connectivity | API and batch |
| Runtime data | Dedicated Pricing Data Store |
| Gateway | MuleSoft for all external integrations |
| Delivery priority | Computing and simulation first |
| Contracting | Partial integration after compute maturity |
| Analytical data | Data Lake Golden Zone |
| Product mapping | T24 Product Code |
| Reference | Temenos Enterprise Product/Pricing capabilities |

## Pricing Engine ownership

- Pricing Product and version.
- Product-code mapping.
- Price components.
- Campaign definition and benefit.
- Factor definitions and accepted values.
- Eligibility and calculation rules.
- Quote, simulation and pricing decision.
- Explainability, evidence and replay.
- Contract-ready pricing instruction.

## Non-ownership

- Customer, account and contract masters.
- Core financial booking and accounting.
- Raw analytical history.
- Enterprise workflow platform.
- External channel presentation.
