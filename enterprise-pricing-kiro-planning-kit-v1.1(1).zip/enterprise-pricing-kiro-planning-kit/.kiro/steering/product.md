---
inclusion: always
---
# Product Overview

The workspace designs an Enterprise Pricing Engine for a bank. It manages pricing products, campaigns, factors, rules, computation, simulation, explainability and later partial contracting integration.

T24 supplies operational data through API and batch. The Data Lake Golden Zone supplies curated analytical factors. MuleSoft is the mandatory gateway for all external connections. The engine owns a dedicated Pricing Data Store. Product resolution starts with T24 Product Code.

Primary delivery objective: produce a safe, auditable computing MVP before expanding into contracting and ML-assisted pricing.
