---
inclusion: always
---
# Architecture Principles

1. Pricing logic belongs in the Pricing Engine.
2. T24 is an operational source, not the new pricing authority.
3. MuleSoft governs integration but must not own pricing business logic.
4. Runtime pricing reads from a controlled Pricing Data Store.
5. Golden Zone data is curated upstream and materialized for runtime use.
6. Every price must be explainable and replayable.
7. Published configuration is immutable; changes create new versions.
8. Compute and contract application have separate consistency and freshness policies.
9. Contracting requires quote revalidation and idempotency.
10. Unknowns must remain explicit; assumptions are never silently converted into facts.
