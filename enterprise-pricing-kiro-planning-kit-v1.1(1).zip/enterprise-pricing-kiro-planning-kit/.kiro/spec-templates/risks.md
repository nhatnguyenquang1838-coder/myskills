# <SPEC-ID> — Risks

| Risk | Severity | Probability | Trigger | Impact | Treatment | Contingency | Owner | Linked tasks |
|---|---|---|---|---|---|---|---|---|
