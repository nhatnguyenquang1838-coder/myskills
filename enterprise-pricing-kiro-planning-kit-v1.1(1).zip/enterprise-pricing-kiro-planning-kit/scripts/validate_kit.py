#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
errors = []

required = [
    'AGENTS.md', '.kiro/steering/product.md', '.kiro/steering/tech.md',
    '.kiro/steering/structure.md', '.kiro/agents/engineering-lead.md',
    'schemas/implementation-plan.schema.json', 'schemas/task.schema.json'
]
for rel in required:
    if not (root / rel).exists(): errors.append(f'missing: {rel}')

for skill in (root / '.kiro/skills').glob('*/SKILL.md'):
    text = skill.read_text(encoding='utf-8')
    folder = skill.parent.name
    m = re.search(r'^name:\s*([^\n]+)$', text, re.M)
    if not m: errors.append(f'{skill}: missing name')
    elif m.group(1).strip() != folder: errors.append(f'{skill}: name must match folder')
    if not re.search(r'^description:\s*.+$', text, re.M): errors.append(f'{skill}: missing description')

if errors:
    print('KIT VALIDATION: FAIL')
    for e in errors: print('-', e)
    raise SystemExit(1)
print(f'KIT VALIDATION: PASS ({len(list((root/".kiro/skills").glob("*/SKILL.md")))} skills)')
