---
inclusion: auto
name: t24-source-boundary
description: Use for T24 data, customer, account, contract, balance, product code, API, batch, source mapping, freshness or core banking integration analysis.
---
# T24 Source Boundary

Treat T24 data as authoritative only for the explicitly mapped operational entities and fields. Create a canonical projection instead of exposing T24 naming throughout the Pricing Engine.

For each field record source application, field, meaning, type, frequency, freshness, quality rule, fallback, sensitivity and owner.

Never design direct database access to T24. Use approved API or batch through the MuleSoft-governed integration boundary.
