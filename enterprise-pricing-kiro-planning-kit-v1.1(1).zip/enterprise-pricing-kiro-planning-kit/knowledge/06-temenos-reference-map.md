# Temenos Capability Reference Map

Use Temenos Enterprise Product/Pricing as a capability benchmark, not as an assumption that this implementation shares its data model.

| Reference capability | Local planning concept |
|---|---|
| Simulated quotation | Pricing Quote and Simulation |
| Pricing adjustment | Controlled manual/rule adjustment |
| Promotions | Campaign and Benefit |
| Party eligibility | Customer and relationship eligibility |
| Pricing transparency | Decision evidence and evaluation trace |
| Package arrangement | Product bundle and relationship pricing |
| Activity pricing | Event/transaction-based computation |
| Periodic pricing | Scheduled fee/rate computation |
| Original/adjusted/final fee | Base component, adjustments and final component |
| Transaction/processing references | Correlation, decision and reconciliation references |

## Planning guardrail

Do not infer a Temenos API or object exists in the target bank. Verify all actual T24 and Temenos interfaces from project evidence.
