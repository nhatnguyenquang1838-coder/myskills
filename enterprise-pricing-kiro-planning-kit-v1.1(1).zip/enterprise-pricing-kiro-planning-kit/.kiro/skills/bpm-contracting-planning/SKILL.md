---
name: bpm-contracting-planning
description: Plan BPM/BPA approvals and partial contracting integration including quote revalidation, instruction state, idempotency, partial success, compensation and reconciliation.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Separate human approval workflow from runtime compute.
2. Define maker/checker, SLA and escalation.
3. Define quote freeze and revalidation.
4. Define contract instruction and target acknowledgement.
5. Model pending, submitted, applied, partially applied, rejected, failed and reconciliation-required states.
6. Define retry, compensation and manual resolution.
7. Identify the financial booking authority.
