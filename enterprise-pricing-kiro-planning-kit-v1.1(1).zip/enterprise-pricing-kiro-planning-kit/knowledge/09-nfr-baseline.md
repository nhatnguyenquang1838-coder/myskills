# NFR Baseline

All numeric values remain assumptions until approved.

| Area | Planning baseline | Verification |
|---|---|---|
| Determinism | Same snapshot and version produces same result | Golden dataset replay |
| Audit | 100% quote and rule-evaluation traceability | Audit completeness test |
| Availability | Define by business journey | Resilience and DR test |
| Latency | Separate quote, batch and contracting SLOs | Load and percentile tests |
| Security | Least privilege and maker/checker | Threat model and access tests |
| Privacy | Minimize copied T24 PII | Data inventory and masking tests |
| Scalability | Horizontal compute scaling | Capacity test |
| Recovery | Idempotent ingestion and contracting | Restart/replay tests |
| Operability | Correlation and actionable alerts | Operational readiness review |
| Data quality | Freshness and quality status on every factor | Data quality controls |
