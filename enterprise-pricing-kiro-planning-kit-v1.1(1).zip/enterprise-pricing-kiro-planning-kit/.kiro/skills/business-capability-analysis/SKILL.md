---
name: business-capability-analysis
description: Analyse business journeys, actors, capabilities, policies and operating model for enterprise pricing. Use for business scope, capability maps, user journeys, approvals and MVP definition.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Identify actors and pricing journeys.
2. Separate design-time, run-time, contracting and operational capabilities.
3. Define business ownership and system ownership.
4. Derive business rules and decision points without inventing policy.
5. Create MVP and later-wave boundaries.
6. Express requirements in EARS-style statements with measurable acceptance criteria.

# Required challenge

Reject vague requirements such as “support campaigns” until campaign eligibility, benefit, period, priority, stacking and cap semantics are represented.
