---
inclusion: always
---
# Spec Output Contract

A generated spec must contain:

- `requirements.md`: journeys, EARS-style requirements and acceptance criteria.
- `design.md`: boundaries, domain model, APIs, data, sequences, security, NFR, migration and options.
- `tasks.md`: dependency-aware atomic tasks.
- `traceability.md`: requirement → design → task → test mapping.
- `decisions.md`: accepted, proposed and unresolved ADRs.
- `risks.md`: severity, trigger, mitigation and owner.
- `source-inventory.md`: all analysed evidence and gaps.

No task may omit source reference, implementation scope, dependencies, acceptance criteria, test strategy, rollback and evidence.
