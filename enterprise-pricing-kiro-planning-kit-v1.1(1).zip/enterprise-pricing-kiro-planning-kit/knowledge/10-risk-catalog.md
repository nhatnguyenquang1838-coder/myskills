# Initial Risk Catalog

| Risk | Severity | Trigger | Required treatment |
|---|---|---|---|
| Pricing logic split across Engine, Mule and channels | Critical | Same rule implemented twice | Establish logic authority and architecture tests |
| Product ownership overlaps T24 | Critical | Conflicting configuration | Lock source/ownership matrix |
| Golden Zone becomes synchronous runtime dependency | Critical | Direct query in quote path | Materialize factors into Pricing Data Store |
| Stale operational data used for contracting | Critical | Quote applied after source changed | Revalidation and freshness gates |
| Non-deterministic rule result | Critical | Same replay produces different outcome | Version snapshots and golden tests |
| Campaign conflict and stacking ambiguity | High | Multiple applicable campaigns | Priority, exclusivity and conflict policy |
| Batch ingestion creates duplicates | High | Restart after partial failure | Idempotent partitions and reconciliation |
| Partial contracting result not recoverable | High | Some components applied | Explicit state model and compensation |
| ML introduced before feedback loop | High | Online model without measured outcome | Shadow mode and deterministic fallback |
| Product Code alone becomes insufficient | Medium | Context changes resolution | Extensible resolver qualifiers |
