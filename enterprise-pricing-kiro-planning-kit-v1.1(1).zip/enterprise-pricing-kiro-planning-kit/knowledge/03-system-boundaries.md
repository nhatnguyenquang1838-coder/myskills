# System Boundaries

## T24

Provides customer, account, contract, balance, status and core Product Code data through approved API and batch interfaces. It does not own the new engine's pricing rules or campaigns.

## MuleSoft

Owns external API exposure, authentication, routing, throttling, protocol mediation, transformation, correlation and integration error routing. Pricing logic must not be implemented in Mule flows.

## Pricing Data Store

Stores canonical operational projections, curated factor values, pricing configuration, decision snapshots and contracting status. It is not a replacement for T24 or the Golden Zone.

## Data Lake Golden Zone

Provides curated, quality-controlled analytical factors and effective timestamps. Runtime calculation must not query raw lake tables synchronously.

## BPM/BPA

Owns human approvals, SLA, escalation and segregation of duties. It does not execute low-latency price calculation.

## Contracting target

Consumes a contract-ready pricing instruction. Financial booking ownership remains external and must be identified per journey.
