---
name: enterprise-pricing-domain
description: Model Enterprise Pricing concepts including pricing products, product-code mappings, components, factors, campaigns, benefits, rules, quotations, decisions and replay.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Build the ubiquitous language.
2. Define aggregates and lifecycle boundaries.
3. Separate immutable published versions from editable drafts.
4. Define deterministic calculation ordering.
5. Define explainability and replay evidence.
6. Identify invariants and conflict cases.

# Minimum aggregates

- PricingProduct
- ProductMapping
- PriceComponent
- FactorDefinition
- FactorValue
- Campaign
- Benefit
- RuleSet
- PricingQuote
- PricingDecision
- ContractInstruction
