---
name: golden-zone-data-planning
description: Plan Data Lake Golden Zone feeds, curated analytical factors, lineage, business dates, data quality, materialization and runtime consumption.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

- Inventory Golden Zone datasets and owners.
- Map curated fields to factor definitions.
- Define full/delta feed, business date, effective time and restatement behavior.
- Define late-arriving and corrected data handling.
- Define materialization into Pricing Data Store.
- Define freshness and quality monitoring.
- Prohibit synchronous raw lake queries in quote processing.
