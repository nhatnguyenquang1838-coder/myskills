# Planning and Estimation Model

## Planning principle

Plan vertically by business/product journey. Estimate horizontally by system and engineering skill. Release by end-to-end value slice.

## Common baseline

Common baseline is work built once and reused by all product slices:

- Repository and module structure.
- CI/CD and environments.
- Authentication and authorization.
- Audit and decision evidence.
- Versioning and effective dating.
- Database migration framework.
- MuleSoft API standards.
- Data ingestion pattern.
- Observability and runbooks.
- Security controls.
- Rule runtime baseline.

Baseline work must not be charged repeatedly to every product slice.

## Feature sizing

Every feature is sized using:

```text
feature type + complexity score + dependency factor + uncertainty factor + AI factor + HITL effort
```

## Complexity dimensions

- Business logic.
- Integration.
- Data.
- Engineering.
- NFR.
- Testing.
- Operations.

## Confidence bands

| Confidence | Criteria |
|---|---|
| High | source confirmed, interface known, testable, no major external dependency |
| Medium | source mostly clear, some assumptions, manageable dependency |
| Low | missing fields/interfaces/SLA, new vendor or unclear owner |

## Contingency guidance

| Confidence mix | Contingency |
|---|---:|
| mostly high | 10–15% |
| mixed high/medium | 15–25% |
| mostly medium/low | 25–40% |
| many unknowns | do not baseline; run clarification phase first |
