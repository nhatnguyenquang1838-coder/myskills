# Enterprise Pricing Planning Instructions

## Mission

Analyse solution material and create implementation-ready requirements, design and tasks for the Enterprise Pricing Engine.

## Authority and boundaries

- Supplied solution documents and approved architecture decisions are authoritative inputs.
- T24 is an upstream operational data source, not the pricing authority.
- MuleSoft is the mandatory gateway and integration contract boundary.
- The Pricing Engine owns pricing product, campaign, factors, rules, computation, quote, decision evidence and replay.
- The Pricing Engine owns a dedicated operational Data Store.
- Data Lake Golden Zone supplies curated analytical factors.
- Product mapping starts with T24 Product Code.
- Compute and simulation are delivered before partial contracting integration.
- Never invent an interface, field, SLA, volume, approval policy or data source. Record unknowns explicitly.

## Planning-only default

Do not edit production code or create implementation commits unless the user explicitly changes the execution mode. Planning output belongs under `.kiro/specs/<SPEC-ID>/`.

## Required workflow

1. Inventory and classify all sources.
2. Build a fact, assumption, decision and open-question register.
3. Map business capabilities and journeys.
4. Validate system ownership and data boundaries.
5. Assess feasibility by Java, MuleSoft, T24, data, BPM, ML, security, testing and operations.
6. Produce options where architecture decisions remain open.
7. Create dependency-aware implementation waves.
8. Generate atomic tasks with acceptance criteria, tests, rollback and evidence.
9. Run architecture review and consistency checks.
10. Publish a traceable plan; never hide unresolved blockers.

## Quality gates

A plan fails if it lacks any of:

- Source traceability.
- Product/campaign/factor domain model.
- T24 and Golden Zone source catalog.
- MuleSoft interface inventory.
- Data freshness classification.
- NFR and security baseline.
- Dependency graph and critical path.
- Test strategy and operational readiness.
- Migration, rollback and reconciliation approach.
- Explicit assumptions and open decisions.

## Output contract

Create:

```text
.kiro/specs/<SPEC-ID>/
├── requirements.md
├── design.md
├── tasks.md
├── traceability.md
├── decisions.md
├── risks.md
└── source-inventory.md
```
