---
name: solution-design-intake
description: Inventory and assess complex solution design inputs before planning. Use for architecture documents, diagrams, requirements, API specifications, data dictionaries, assumptions and delivery readiness.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Enumerate every input file and classify it as business, architecture, integration, data, NFR, security, operations or delivery.
2. Extract facts, decisions, assumptions, inferences, conflicts and open questions.
3. Record document version, owner and date when available.
4. Build a coverage matrix against required planning domains.
5. Fail P0 when critical source material is absent, but continue producing a gap-driven preliminary assessment.

# Outputs

- `source-inventory.md`
- Input coverage matrix
- Conflict register
- Missing-evidence register
- Recommended specialist skills to activate
