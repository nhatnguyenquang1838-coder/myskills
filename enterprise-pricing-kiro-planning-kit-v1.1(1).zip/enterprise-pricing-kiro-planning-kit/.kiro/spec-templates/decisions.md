# <SPEC-ID> — Decisions

| ADR | Decision | Status | Options | Rationale | Consequences | Evidence | Owner |
|---|---|---|---|---|---|---|---|
