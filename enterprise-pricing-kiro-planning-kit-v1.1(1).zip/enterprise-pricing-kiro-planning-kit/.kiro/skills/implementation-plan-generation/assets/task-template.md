## TASK-ID — Title

- Requirement: REQ-ID
- Design component: DESIGN-ID
- Owner skill:
- Dependencies:
- Complexity:
- Effort assumption:

### Objective

### Scope

### Implementation guidance

### Acceptance criteria

### Test evidence

### Migration and rollback

### Risks and assumptions
