# Domain Invariants

- A published version cannot be edited.
- Active date ranges cannot conflict for the same resolution key.
- Every final component traces to a base value and adjustments.
- Every factor has a source, effective time and quality/freshness state.
- Campaign conflict resolution is deterministic.
- A consumed or expired quote cannot be silently modified.
