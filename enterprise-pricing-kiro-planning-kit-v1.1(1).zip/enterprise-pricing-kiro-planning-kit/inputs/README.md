# Input Placement

- `solution/`: solution design, architecture and business documents.
- `interfaces/`: OpenAPI, RAML, event schemas, file layouts and integration inventory.
- `data/`: T24 dictionaries, Golden Zone catalogs and field mappings.
- `nfr/`: volume, performance, DR, security and operations requirements.
- `decisions/`: approved ADRs and project decisions.

Do not place secrets or production credentials here.
