---
name: devops-release-deployment
description: Plan DevOps, CI/CD, environments, release trains, deployment strategy, rollback, observability, runbooks, and production readiness for Enterprise Pricing.
metadata:
  domain: enterprise-pricing
  version: "1.1"
---

# Purpose

Create release, deployment and operations plans that are measurable and executable.

# Required planning areas

- Environment strategy.
- Branching and release model.
- CI/CD pipeline.
- Infrastructure and configuration.
- Database migration and rollback.
- Feature flags.
- Secrets and config management.
- Observability and alerting.
- Performance testing gates.
- Production readiness checklist.
- Incident and rollback runbook.

# Release model

Recommended stages:

```text
DEV → SIT → INT/E2E → UAT → NFT/PT → OAT → Pilot → Production
```

Every release must define:

- Release objective.
- Included features.
- Excluded features.
- Migration steps.
- Deployment steps.
- Smoke tests.
- Rollback criteria.
- Monitoring window.
- Support owner.

# Deployment patterns

Choose per component:

| Component | Preferred pattern |
|---|---|
| Pricing API | blue/green or canary |
| Batch ingestion | controlled schedule with restartability |
| Rule config | version activation with rollback |
| Database schema | backward-compatible migration |
| MuleSoft API | versioned API deployment |
| Golden Zone factors | replayable batch feed |

# Output contract

Produce:

```yaml
release_plan:
  releases:
    - release_id:
      scope:
      entry_criteria:
      exit_criteria:
      environments:
      deployment_steps:
      rollback:
      smoke_tests:
      monitoring:

deployment_plan:
  components:
  sequence:
  freeze_window:
  cutover:
  rollback:

ops_readiness:
  dashboards:
  alerts:
  runbooks:
  support_model:
```
