# <SPEC-ID> — Design

## Source and decision baseline

## Context and ownership

## Bounded contexts and components

## Domain model

## Calculation sequence

## T24 source design

## MuleSoft integration design

## Golden Zone and factor design

## Data Store design

## Rules and explainability

## BPM and contracting design

## API/event/batch contracts

## Security and privacy

## NFR and capacity

## Migration, rollout and rollback

## Observability and operations

## Architecture options and ADRs

## Risks and unresolved decisions
