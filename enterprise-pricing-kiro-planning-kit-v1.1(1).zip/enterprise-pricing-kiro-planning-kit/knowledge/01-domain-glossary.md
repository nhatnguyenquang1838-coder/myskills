# Domain Glossary

| Term | Definition |
|---|---|
| Pricing Product | Versioned pricing configuration selected from a source product code and context. |
| Product Code | T24-provided identifier used as the primary pricing-product mapping key. |
| Price Component | A fee, rate, cashback, margin or charge independently computed and explained. |
| Factor | A typed input used by eligibility or pricing calculation. |
| Operational Factor | Current data sourced from T24 or another operational system. |
| Analytical Factor | Curated derived value supplied from the Golden Zone. |
| Campaign | Time-bound eligibility and benefit definition. |
| Benefit | Waiver, discount, uplift, reduction, cashback or bundle advantage. |
| Guardrail | Mandatory floor, cap, regulatory, risk or profitability constraint. |
| Pricing Quote | Immutable result produced from a specific input and configuration snapshot. |
| Pricing Decision | Full evidence explaining qualification, adjustments and final values. |
| Contract Instruction | Idempotent instruction derived from an approved, revalidated quote. |
| Replay | Re-execution using the original snapshots and versions. |
| Freshness Class | Policy specifying maximum age and stale-data handling. |
| Golden Zone | Governed curated Data Lake layer supplying trusted analytical values. |
