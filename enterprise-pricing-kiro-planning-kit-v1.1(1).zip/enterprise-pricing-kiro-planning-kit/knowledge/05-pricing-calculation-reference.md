# Pricing Calculation Reference

```text
Validate request
→ Resolve product code and context
→ Load canonical customer/account/contract projection
→ Load Golden Zone factors
→ Evaluate freshness and quality
→ Evaluate eligibility
→ Resolve base price components
→ Apply factor adjustments
→ Apply campaign benefits
→ Apply approved manual adjustments
→ Enforce guardrails
→ Round and normalize
→ Persist immutable quote and evidence
```

## Determinism rule

The same request data, source snapshots, configuration versions and engine version must produce the same result.

## Evidence per component

- Base value.
- Rule or formula.
- Factors read and their source timestamps.
- Campaigns considered, qualified and rejected.
- Adjustment amount and ordering.
- Guardrail action.
- Final value.
- Warnings and stale-data decisions.
