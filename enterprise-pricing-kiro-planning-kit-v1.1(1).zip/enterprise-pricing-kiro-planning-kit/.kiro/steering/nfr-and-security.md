---
inclusion: auto
name: nfr-and-security
description: Use for performance, availability, resilience, DR, security, privacy, audit, operations, volume, testing or production readiness.
---
# NFR and Security Rules

Do not invent numeric targets. Mark proposed baselines as assumptions and identify the approving owner.

Every plan must cover latency, throughput, batch window, availability, recovery, deterministic replay, audit retention, access control, maker/checker, PII minimization, encryption, observability and incident recovery.
