---
name: pricing-factor-catalog
description: Create a governed pricing factor catalog across T24 operational data and Golden Zone analytical data, including type, lineage, freshness, quality and fallback.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Inventory every factor required by eligibility and calculation.
2. Map source field to canonical factor.
3. Classify operational versus analytical.
4. Define type, units, precision, effective time and subject key.
5. Assign freshness class and stale-data policy.
6. Define quality checks and fallback.
7. Identify PII and retention.
8. Produce ingestion and runtime access requirements.
