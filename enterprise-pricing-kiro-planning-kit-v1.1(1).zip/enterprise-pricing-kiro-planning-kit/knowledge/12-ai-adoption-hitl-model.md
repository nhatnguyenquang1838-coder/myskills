# AI Adoption and Human-in-the-Loop Model

## AI placement

AI can accelerate planning and development, but it cannot become the authority for pricing, security, budget or production release decisions.

## Useful AI zones

- BRD/FSD extraction.
- Requirement traceability draft.
- API contract first draft.
- Java boilerplate.
- Unit test generation.
- Rule scenario matrix.
- Mapping code first draft.
- Gantt/resource calculation draft.
- Release runbook draft.
- Threat checklist draft.

## HITL gates

| Gate | Human owner |
|---|---|
| Product pricing semantics | Business/Product owner |
| T24 source mapping | T24 lead/Data owner |
| Golden Zone factor definition | Data owner |
| MuleSoft API contract | Integration lead |
| Rule calculation sequence | Pricing rules lead |
| Security controls | Security lead |
| Cost/timeline commitment | PM/SteerCo |
| Production release | Release manager |

## Estimation impact

AI productivity must be recorded as an assumption and tied to task types. Never apply a blanket productivity discount to the whole project.
