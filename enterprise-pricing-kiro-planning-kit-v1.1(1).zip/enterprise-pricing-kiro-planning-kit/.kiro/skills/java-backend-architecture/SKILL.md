---
name: java-backend-architecture
description: Create Java and Spring Boot implementation architecture, modules, service boundaries, persistence, APIs, concurrency, observability and test strategy for the Pricing Engine.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Derive modules from bounded contexts, not technical layers alone.
2. Define transaction boundaries and consistency model.
3. Define API/application/domain/infrastructure separation.
4. Design versioning, effective dating and immutable decision persistence.
5. Address concurrency, idempotency and caching.
6. Specify database migrations and backward compatibility.
7. Define unit, integration, contract and architecture tests.
8. Reference actual repository patterns when available.
