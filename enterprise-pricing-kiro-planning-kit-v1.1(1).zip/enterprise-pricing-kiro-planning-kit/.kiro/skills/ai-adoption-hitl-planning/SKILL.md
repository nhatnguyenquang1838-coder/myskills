---
name: ai-adoption-hitl-planning
description: Determine where AI should assist engineering delivery, where human-in-the-loop approval is mandatory, and how AI productivity affects estimates safely.
metadata:
  domain: enterprise-pricing
  version: "1.1"
---

# Purpose

Place AI deliberately in delivery without weakening governance, security or pricing correctness.

# AI placement matrix

| Delivery activity | AI use | Human owner |
|---|---|---|
| BRD/FSD extraction | summarize, classify, trace requirements | BA Lead |
| Source inventory | detect missing/conflicting docs | Engineering Lead |
| API contract draft | generate first OAS/RAML draft | MuleSoft Lead |
| Java scaffolding | create DTOs, controllers, tests | Java Lead |
| Mapping code | generate first mapper and unit tests | Engineer |
| Rule test cases | generate scenario matrix | Pricing Rules Lead |
| Gantt/resource draft | calculate first-cut plan | PM |
| Security checklist | draft STRIDE-style risks | Security Lead |
| Release runbook | draft sequence and rollback | DevOps Lead |

# AI exclusion zones

AI must not own final decisions for:

- Pricing rule approval.
- Security exception acceptance.
- Production release go/no-go.
- Contracting financial instruction approval.
- Final cost/budget commitment.
- Vendor or regulatory sign-off.
- Secrets handling.

# HITL levels

| Level | Meaning | Example |
|---|---|---|
| H0 | AI allowed, peer review enough | DTO/test generation |
| H1 | Lead review required | API contract, data mapping |
| H2 | Architect/security review required | NFR, security, data lineage |
| H3 | Business/risk approval required | pricing rules, campaign impact |
| H4 | Steering approval required | scope/budget/date commitment |

# Estimation impact

Apply AI productivity only when:

- Existing coding standards are available.
- Generated output can be tested automatically.
- Human review capacity exists.
- Task is not decision-heavy.

Default AI factor:

```yaml
boilerplate_and_tests: 0.70-0.85
api_contract_draft: 0.80-0.90
integration_logic: 0.90-1.00
pricing_logic: 0.95-1.10
security_design: 1.00
production_approval: 1.00
```

AI may increase effort when governance review overhead is high.

# Output contract

Produce:

```yaml
ai_adoption_plan:
  ai_enabled_activities:
  ai_exclusion_zones:
  hitl_gates:
  productivity_assumptions:
  review_capacity:
  risks:
  evidence_required:
```
