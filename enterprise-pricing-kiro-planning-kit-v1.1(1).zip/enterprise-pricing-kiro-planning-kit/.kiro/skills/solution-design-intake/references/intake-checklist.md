# Intake Checklist

- Business objectives and journeys
- Pricing capability scope
- Product/campaign/factor definitions
- T24 interfaces and data dictionary
- MuleSoft standards and existing APIs
- Golden Zone datasets and SLAs
- Contracting target and workflow
- Security and compliance
- NFR and volumes
- Deployment and support model
- Existing ADRs and constraints
