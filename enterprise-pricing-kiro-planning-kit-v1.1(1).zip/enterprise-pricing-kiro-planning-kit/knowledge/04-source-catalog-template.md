# Source Catalog Template

Use one row per pricing-relevant source field.

| Source system | Entity | Source field | Business meaning | Canonical field | Consumer | Mode | Frequency | Freshness class | Quality checks | Fallback | Owner | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Mandatory classifications

- Authority: master, projection, derived or reference.
- Sensitivity: public, internal, confidential or restricted.
- Timeliness: event-time, source-update-time and ingestion-time.
- Failure policy: reject, fallback, warn or degrade.
- Retention and replay requirement.
