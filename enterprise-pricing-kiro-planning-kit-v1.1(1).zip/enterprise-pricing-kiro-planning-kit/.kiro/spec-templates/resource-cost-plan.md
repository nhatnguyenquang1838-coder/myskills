# Resource and Cost Plan

## Resource Plan

| Role | Skill | FTE | Start | End | Person-months | Notes |
|---|---|---:|---|---|---:|---|

## Cost Plan

| Role/Cost item | Quantity | Duration | Rate assumption | Cost range | Confidence |
|---|---:|---:|---:|---:|---|

## Contingency

## Cost Risks
