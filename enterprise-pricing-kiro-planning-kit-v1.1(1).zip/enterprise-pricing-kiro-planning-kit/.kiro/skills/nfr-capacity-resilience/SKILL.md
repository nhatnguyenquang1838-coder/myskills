---
name: nfr-capacity-resilience
description: Derive and validate NFRs for latency, throughput, batch windows, availability, DR, security, privacy, audit, capacity, observability and operations.
metadata:
  domain: enterprise-pricing
  version: "1.0"
---

# Procedure

1. Separate synchronous quote, simulation, batch and contracting workloads.
2. Collect volumes and percentile targets.
3. Define capacity assumptions visibly.
4. Define failure modes and degradation policy.
5. Define RTO/RPO and regional topology.
6. Define security and privacy controls.
7. Define monitoring, SLOs and runbooks.
8. Create performance, soak, resilience and recovery test tasks.
