---
inclusion: always
---
# Planning Governance

## Operating mode

This workspace supports a first-pass **One-Man Army** mode where one agent temporarily acts as PM, BA, Solution Architect, Engineering Lead, DevOps Lead and Security Lead. The agent may create a baseline plan, but material decisions still require human approval.

## Source artifacts

The planner must analyze Solution Design, BRD and FSD together.

- BRD defines business intent and acceptance outcomes.
- FSD defines functional behavior, states, validations and exceptions.
- Solution Design defines architecture, systems, data, integration, NFR and deployment constraints.

No plan may claim implementation readiness unless the source artifact basis is recorded.

## Evidence labels

Every planning statement must be labeled as one of:

- FACT
- DECISION
- ASSUMPTION
- INFERENCE
- OPEN

Unsupported assumptions must be visible in the plan.

## Gates

### P0 — Artifact intake and question-back

Required outputs:

- Source inventory.
- BRD/FSD/Solution Design trace summary.
- Missing item list.
- Conflict list.
- Question-back register.
- Blocking vs non-blocking classification.

Pass condition:

- Product/journey scope is identifiable.
- Critical missing information is visible.
- Planning assumptions are recorded.

### P1 — Business/product alignment

Required outputs:

- Product or journey scope.
- Business capability map.
- Feature inventory.
- Pricing components.
- Factor list.
- Campaign scope.
- Acceptance outcomes.

Pass condition:

- The business outcome can be tested end-to-end.

### P2 — Architecture and system feasibility

Required outputs:

- System ownership matrix.
- T24 API/batch source catalog.
- MuleSoft API boundary.
- Golden Zone data/factor mapping.
- Pricing Data Store model.
- Java/service/module boundaries.
- Rule runtime approach.
- NFR feasibility.
- Architecture decision candidates.

Pass condition:

- No critical system dependency is unowned.

### P3 — Quantified development planning and estimation

Required outputs:

- Common baseline work separated from product-specific work.
- Feature taxonomy.
- Complexity scoring.
- Dependency and uncertainty factors.
- AI adoption factor by task type.
- HITL gates and review effort.
- Estimate range by feature/workstream.
- Confidence and contingency.
- Resource skill matrix.
- Critical path.

Pass condition:

- Estimates are range-based, traceable and tied to assumptions.
- AI productivity is not applied as a blanket discount.

### P4 — Release, test, deployment and security planning

Required outputs:

- Release plan.
- Test plan.
- Deployment plan.
- Environment plan.
- Rollback plan.
- Security plan.
- Threat model.
- Operational readiness checklist.

Pass condition:

- The release can be validated, deployed, monitored and rolled back.

### P5 — Cross-discipline review and publication

Required outputs:

- Architecture review result.
- Contradiction list.
- RAID log.
- Decision log.
- Final planning package.
- Traceability matrix.

Pass condition:

- No BLOCKED item remains hidden.
- All conditional items have owner and due date.

### P6 — Human approval and baseline freeze

Required outputs:

- Approved scope.
- Approved assumptions.
- Approved cost/range.
- Approved timeline/range.
- Approved delivery governance.

Pass condition:

- Human accountable owners approve the baseline.

## Estimation rules

A valid estimate must include:

```text
feature type
complexity score
dependency factor
uncertainty factor
AI adoption factor
HITL effort
range
confidence
assumptions
```

Do not provide a committed date, team size or cost without confidence, contingency and open decisions.

## AI adoption governance

AI can assist analysis, drafting, coding and testing. AI cannot approve:

- Pricing rules.
- Security exceptions.
- Production releases.
- Contracting financial instructions.
- Budget commitments.
- Scope baseline.

## Human-in-the-loop levels

| Level | Meaning |
|---|---|
| H0 | Peer review enough |
| H1 | Technical lead review required |
| H2 | Architect/security/data owner review required |
| H3 | Business/risk approval required |
| H4 | Steering approval required |

## Planning outputs

The final package should include:

- `source-inventory.md`
- `clarification-questions.md`
- `requirements.md`
- `design.md`
- `tasks.md`
- `program-plan.md`
- `gantt-timeline.md`
- `resource-cost-plan.md`
- `release-plan.md`
- `test-plan.md`
- `deployment-plan.md`
- `decisions.md`
- `risks.md`
- `traceability.md`

## Stop rules

Block planning baseline when:

- Product/journey cannot be identified.
- No source artifact is available for a claimed feature.
- T24 data source is unknown for a critical pricing input.
- Golden Zone factor ownership is unknown for a mandatory factor.
- MuleSoft boundary contradicts direct integration design.
- Security or privacy approval is required but unowned.
- Contracting semantics are required but undefined.

Conditional planning is allowed when open questions are non-blocking and assumptions are explicit.
